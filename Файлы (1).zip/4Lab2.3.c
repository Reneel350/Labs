#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <time.h>

#define MIN_LENGTH 10
#define MAX_LENGTH 20

int main() {
    char str[MAX_LENGTH + 1];
    int length = (rand() % (MAX_LENGTH - MIN_LENGTH + 1)) + MIN_LENGTH;
    int i;
    srand(time(NULL));


    for (i = 0; i < length; i++) {
        int rand_num = rand() % 4;

        if (rand_num == 0) {
            str[i] = rand() % 10 + '0';
        } else if (rand_num == 1) {
            str[i] = rand() % 26 + 'A';
        } else if (rand_num == 2) {
            str[i] = rand() % 26 + 'a';
        } else {
            int punc_nums[] = {33, 34, 39, 44, 45, 46, 58, 59, 63};
            int rand_punc = rand() % 9;
            str[i] = punc_nums[rand_punc];
        }
    }

    str[length] = '\0';

    printf("Random string: %s\n\n", str);

// testing each character
    for (i = 0; i < length; i++) {
        printf("Testing character %d: %c\n", i, str[i]);
        if (isalpha(str[i])) {
            printf("Alphabetic character found.\n");
            if (isupper(str[i])) {
                printf("Uppercase letter found.\n");
            } else {
                printf("Lowercase letter found.\n");
            }
        } else if (isdigit(str[i])) {
            printf("Digit found.\n");
        } else if (isspace(str[i])) {
            printf("Whitespace found.\n");
        } else {
            printf("Special character found.\n");
            if (ispunct(str[i])) {
                printf("Punctuation mark found.\n");
            }
        }
        printf("\n");
    }

    return 0;
}