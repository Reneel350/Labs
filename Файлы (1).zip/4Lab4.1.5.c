#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MY_SIZE 20

int main() {
    char my_string[MY_SIZE];
    printf("Введите строку (длина не более 10 символов): ");
    fgets(my_string, MY_SIZE, stdin);

    char *string1 = "hello";
    char *string2 = "world";

    char *result_string = (char *) malloc(
            strlen(string1) + strlen(string2) + 1);
    strcpy(result_string, string1);
    strcat(result_string, string2);

    printf("%s\n", result_string);

    free(result_string);
    return 0;
}