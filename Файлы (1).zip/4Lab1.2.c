#include <stdio.h>
#include <stdlib.h>

void swap_even_odd(int* arr, int size) {
    for(int i = 0; i < size - 1; i += 2) {
        int temp = arr[i];
        arr[i] = arr[i+1];
        arr[i+1] = temp;
    }
}

int main() {
    int* arr = (int*)malloc(12 * sizeof(int));
    for(int i = 0; i < 12; i++) {
        arr[i] = i;
    }
    swap_even_odd(arr, 12);
    for(int i = 0; i < 12; i++) {
        printf("%d ", arr[i]);
    }
    free(arr);
    return 0;
}