#include <stdio.h>
#include <stdlib.h>

#define MY_SIZE 20

int main() {
    char my_string[MY_SIZE];
    printf("Введите строку: ");
    fgets(my_string, MY_SIZE, stdin);
    int length = 0;
    for (int i = 0; my_string[i] != '\0'; i++) {
        length++;
    }
    printf("Длина строки: %d\n", length);
    return 0;
}