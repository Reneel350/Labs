#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MY_SIZE 20

int main() {
    char my_string[MY_SIZE];
    printf("Введите строку:\n");
    fgets(my_string, MY_SIZE, stdin);
    int len = strlen(my_string);
    my_string[len - 1] = '\0';

    char *my_string_copy = (char *) malloc(MY_SIZE * sizeof(char));
    strcpy(my_string_copy, my_string);
    printf("Строка: %s\n", my_string);
    printf("Копия строки: %s\n", my_string_copy);

    free(my_string_copy);

    return 0;
}