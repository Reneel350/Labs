#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>

#define MY_SIZE 20

int main() {
    char my_string[MY_SIZE];
    printf("Enter a string with no more than 10 characters: ");
    fgets(my_string, sizeof(my_string), stdin);

    int len = strlen(my_string);
    if (len > 0 && my_string[len-1] == '\n') {
        my_string[len-1] = '\0';
    }

    char* lower_string = (char*)malloc(MY_SIZE * sizeof(char));
    char* upper_string = (char*)malloc(MY_SIZE * sizeof(char));


    for (int i = 0; i < strlen(my_string); i++) {
        lower_string[i] = tolower(my_string[i]);
    }
    lower_string[len] = '\0';

// converting the string to uppercase
    for (int i = 0; i < strlen(my_string); i++) {
        upper_string[i] = toupper(my_string[i]);
    }
    upper_string[len] = '\0';

    printf("Original string: %s\n", my_string);
    printf("Lowercase string: %s\n", lower_string);
    printf("Uppercase string: %s\n", upper_string);

    free(lower_string);
    free(upper_string);

    return 0;
}