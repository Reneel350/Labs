#include <stdio.h>
#include <stdlib.h>

#define MY_SIZE 20

int main() {
    char my_string[MY_SIZE];
    printf("Введите строку (не больше %d символов):\n", MY_SIZE - 1);
    fgets(my_string, MY_SIZE, stdin);
    int length = 0;
    char *ptr = my_string;

    for (; *ptr != '\0'; ptr++, length++) {

    }

    printf("Длина строки: %d\n", length);

    return 0;
}