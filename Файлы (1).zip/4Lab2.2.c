#include <stdio.h>
#include <stdlib.h>

int main() {
    char strDouble[20], strInt[20];
    double doubleNum;
    int intNum;

    printf("Enter a double number: ");
    scanf("%s", strDouble);

    printf("Enter an integer number: ");
    scanf("%s", strInt);

    doubleNum = atof(strDouble);
    intNum = atoi(strInt);

    printf("Double number: %lf\n", doubleNum);
    printf("Integer number: %d\n", intNum);

    return 0;
}