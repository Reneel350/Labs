#include <stdio.h>
#include <stdlib.h>

double **createMatrix(int rows, int cols);
void deleteMatrix(double **matrix, int rows);
void fillMatrix(double **matrix, int rows, int cols);
void printMatrix(double **matrix, int rows, int cols);

int main() {
    int rows, cols;
    double **matrix;
    printf("Enter number of rows: ");
    scanf("%d", &rows);

    printf("Enter number of columns: ");
    scanf("%d", &cols);

    matrix = createMatrix(rows, cols);
    fillMatrix(matrix, rows, cols);

    printf("Matrix:\n");
    printMatrix(matrix, rows, cols);

    deleteMatrix(matrix, rows);

    return 0;
}

double **createMatrix(int rows, int cols) {
    int i;
    double **matrix = malloc(rows * sizeof(double *));
    for (i = 0; i < rows; i++) {
        matrix[i] = malloc(cols * sizeof(double));
    }
    return matrix;
}

void deleteMatrix(double **matrix, int rows) {
    int i;
    for (i = 0; i < rows; i++) {
        free(matrix[i]);
    }
    free(matrix);
}

void fillMatrix(double **matrix, int rows, int cols) {
    int i, j;
    for (i = 0; i < rows; i++) {
        for (j = 0; j < cols; j++) {
            printf("Enter value for matrix[%d][%d]: ", i, j);
            scanf("%lf", &matrix[i][j]);
        }
    }
}

void printMatrix(double **matrix, int rows, int cols) {
    int i, j;
    for (i = 0; i < rows; i++) {
        for (j = 0; j < cols; j++) {
            printf("%lf ", matrix[i][j]);
        }
        printf("\n");
    }
}