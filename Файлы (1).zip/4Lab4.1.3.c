#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MY_SIZE 20

int main() {
    char my_string[MY_SIZE];
    printf("Введите строку (не более 10 символов):\n");
    fgets(my_string, MY_SIZE, stdin);
    size_t input_len = strlen(my_string);
    if (my_string[input_len - 1] == '\n') {
        my_string[input_len - 1] = '\0';
        input_len--;
    }

    printf("Введенная строка: %s\n", my_string);
    printf("Длина строки: %zu\n", input_len);


    char *dyn_string = malloc(input_len * sizeof(char));
    strncpy(dyn_string, my_string, input_len);
    printf("Динамически созданная строка: %s\n", dyn_string);
    printf("Длина динамически созданной строки: %zu\n", strlen(dyn_string));


    free(dyn_string);

    return 0;
}