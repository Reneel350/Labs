#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MY_SIZE 20

int main() {
    char my_string[MY_SIZE];
    printf("Enter a string: ");
    fgets(my_string, MY_SIZE, stdin);
    char* dynamic_string = (char*) malloc(sizeof(char) * MY_SIZE);
    strcpy(dynamic_string, "Hello, world!");

    int cmp_result = strcmp(my_string, dynamic_string);
    if (cmp_result == 0) {
        printf("The two strings are equal.\n");
    } else if (cmp_result > 0) {
        printf("The first string is greater.\n");
    } else {
        printf("The second string is greater.\n");
    }

    free(dynamic_string);
    return 0;
}