#include <stdio.h>

void crossProduct(double *vec1, double *vec2, double *crossProd) {
    crossProd[0] = vec1[1] * vec2[2] - vec1[2] * vec2[1];
    crossProd[1] = vec1[2] * vec2[0] - vec1[0] * vec2[2];
    crossProd[2] = vec1[0] * vec2[1] - vec1[1] * vec2[0];
}

int main() {
    double vec1[3] = {1.0, 2.0, 3.0};
    double vec2[3] = {4.0, 5.0, 6.0};
    double crossProd[3] = {0.0, 0.0, 0.0};

    printf("Vector 1: [%f, %f, %f]\n", vec1[0], vec1[1], vec1[2]);
    printf("Vector 2: [%f, %f, %f]\n", vec2[0], vec2[1], vec2[2]);

    crossProduct(vec1, vec2, crossProd);

    printf("Cross product: [%f, %f, %f]\n", crossProd[0], crossProd[1], crossProd[2]);

    return 0;
}