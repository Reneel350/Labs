#include <stdio.h>
#include <string.h>

struct Student {
    unsigned int id;
    char name[50];
    char faculty[50];
    float rating;
};

void writeToFile(struct Student *students, int size) {
    FILE *file;
    file = fopen("students.csv", "a");
    if (file != NULL) {
        for (int i = 0; i < size; i++) {
            fprintf(file, "%d,%s,%s,%.2f\n", students[i].id, students[i].name, students[i].faculty, students[i].rating);
        }
        fclose(file);
        printf("Data has been saved to a file.\n");
    } else {
        printf("Error opening file.\n");
    }
}

void readFromFile() {
    FILE *file;
    char line[100];
    struct Student student;
    file = fopen("students.csv", "r");
    if (file != NULL) {
        printf("Data read from file:\n");
        while (fgets(line, 100, file)) {
            sscanf(line, "%d,%[^,],%[^,],%f", &student.id, student.name, student.faculty, &student.rating);
            printf("%d %s %s %.2f\n", student.id, student.name, student.faculty, student.rating);
        }
        fclose(file);
    } else {
        printf("Error opening file.\n");
    }
}

int main() {
    struct Student students[3];
    for (int i = 0; i < 3; i++) {
        printf("Enter data for student %d:\n", i+1);
        printf("ID: ");
        scanf("%d", &students[i].id);
        printf("Name: ");
        scanf("%s", students[i].name);
        printf("Faculty: ");
        scanf("%s", students[i].faculty);
        printf("Rating: ");
        scanf("%f", &students[i].rating);
    }
    writeToFile(students, 3);
    readFromFile();
    return 0;
}