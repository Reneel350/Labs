#include <stdio.h>
#include <stdlib.h>

struct Student {
    unsigned int id;
    char name[50];
    char faculty[50];
    float rating;
};

int main() {
    struct Student students[3];
    FILE *file;
    file = fopen("students.bin", "wb");
    if (file == NULL) {
        printf("Не удалось открыть файл!");
        exit(1);
    }


    for (int i = 0; i < 3; i++) {
        printf("Введите данные для студента %d:\n", i+1);
        printf("id: ");
        scanf("%d", &students[i].id);
        printf("Имя и фамилия: ");
        scanf("%s", students[i].name);
        printf("Факультет: ");
        scanf("%s", students[i].faculty);
        printf("Рейтинг: ");
        scanf("%f", &students[i].rating);

        fwrite(&students[i], sizeof(struct Student), 1, file);
    }


    fclose(file);


    file = fopen("students.bin", "rb");
    if (file == NULL) {
        printf("Не удалось открыть файл!");
        exit(1);
    }

    struct Student students2[3];

    for (int i = 0; i < 3; i++) {
        fread(&students2[i], sizeof(struct Student), 1, file);

        printf("\nСтудент %d:\n", i+1);
        printf("id: %d\n", students2[i].id);
        printf("Имя и фамилия: %s\n", students2[i].name);
        printf("Факультет: %s\n", students2[i].faculty);
        printf("Рейтинг: %.2f\n", students2[i].rating);
    }


    fclose(file);

    return 0;
}